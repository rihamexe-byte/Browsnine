import { useEffect, useState, useRef } from 'react';
import { motion } from 'motion/react';
import { Instagram, Facebook, ArrowDown, ExternalLink, ImagePlus, User } from 'lucide-react';

// Custom hook to manage the user's uploaded profile picture via IndexedDB for large image support
function useProfileImage() {
  const [image, setImage] = useState<string | null>(null);

  // Initialize and fetch from IndexedDB
  useEffect(() => {
    const request = indexedDB.open('RihamProfileDB', 1);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains('images')) {
        db.createObjectStore('images');
      }
    };

    request.onsuccess = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      const transaction = db.transaction(['images'], 'readonly');
      const store = transaction.objectStore('images');
      const getRequest = store.get('profile-pic');

      getRequest.onsuccess = () => {
        if (getRequest.result) {
          setImage(getRequest.result);
        }
      };
    };
  }, []);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setImage(result);
        
        // Save to IndexedDB
        const request = indexedDB.open('RihamProfileDB', 1);
        request.onsuccess = (event) => {
          const db = (event.target as IDBOpenDBRequest).result;
          const transaction = db.transaction(['images'], 'readwrite');
          const store = transaction.objectStore('images');
          store.put(result, 'profile-pic');
        };
      };
      reader.readAsDataURL(file);
    }
  };

  return { image, handleImageUpload };
}

export default function App() {
  const [isLoading, setIsLoading] = useState(true);
  const { image, handleImageUpload } = useProfileImage();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Artificial loading state for the premium animation feel
  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-[#0a0a0a]">
        <motion.div
          animate={{ scale: [1, 1.1, 1], opacity: [0.5, 1, 0.5] }}
          transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
          className="text-purple-400 font-heading text-3xl tracking-[0.3em] font-bold"
        >
          RIHAM
        </motion.div>
      </div>
    );
  }

  // Removed the car placeholder image entirely. If there's no image uploaded yet, we show a clean user icon.

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white font-sans relative overflow-x-hidden selection:bg-purple-500/30 selection:text-purple-300">
      
      {/* Background Ambient Glows (Purple and Ash) */}
      <div className="fixed top-[-10%] left-[-10%] w-[40%] h-[40%] bg-purple-900/20 rounded-full blur-[120px] pointer-events-none" />
      <div className="fixed bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-slate-400/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="fixed top-[40%] right-[-20%] w-[30%] h-[30%] bg-purple-600/10 rounded-full blur-[120px] pointer-events-none" />

      {/* Hidden File Input for Image Upload */}
      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleImageUpload} 
        accept="image/*" 
        className="hidden" 
      />

      <main className="max-w-5xl mx-auto px-6 py-12 relative z-10 flex flex-col items-center">
        
        {/* 1. Hero Section */}
        <section className="flex flex-col items-center text-center pt-10 min-h-[85vh] justify-center w-full">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="relative group cursor-pointer"
            onClick={() => fileInputRef.current?.click()}
            title="Click to insert your photo"
          >
            <div className="w-40 h-40 md:w-48 md:h-48 rounded-full overflow-hidden border-2 border-white/10 group-hover:border-purple-500/50 transition-colors duration-500 purple-glow-box p-1 flex items-center justify-center bg-white/5">
              {image ? (
                <img src={image} alt="Riham" className="w-full h-full object-cover rounded-full" />
              ) : (
                <User className="w-20 h-20 text-slate-500" />
              )}
            </div>
            
            {/* Image Upload Overlay Indicator */}
            <div className="absolute inset-0 bg-black/50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center backdrop-blur-sm">
              <ImagePlus className="w-8 h-8 text-white" />
            </div>
          </motion.div>

          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="mt-8 text-5xl md:text-7xl font-bold font-heading tracking-tight"
          >
            Riham
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="mt-6 text-lg md:text-xl text-slate-400 font-light max-w-md leading-relaxed"
          >
            Welcome to my personal website
          </motion.p>

          <motion.button
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            onClick={() => document.getElementById('about')?.scrollIntoView()}
            className="mt-12 px-8 py-3 rounded-full bg-white/5 border border-white/10 text-white font-medium hover:bg-purple-500/10 hover:border-purple-500/50 hover:text-purple-400 transition-all duration-300 purple-glow-box-hover flex items-center gap-2"
          >
            Connect With Me
            <ArrowDown className="w-4 h-4" />
          </motion.button>
        </section>

        {/* 2. About Section */}
        <section id="about" className="w-full py-24 scroll-mt-10">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.7 }}
            className="glass-panel rounded-[2rem] p-8 md:p-14 text-center max-w-3xl mx-auto purple-glow-box-hover"
          >
            <h2 className="text-3xl md:text-4xl font-heading font-semibold mb-6">About Me</h2>
            <p className="text-slate-300 leading-relaxed text-lg md:text-xl font-light">
              Hi, I'm Riham. This is my personal space on the internet where you can connect with me and explore my social profiles.
            </p>
          </motion.div>
        </section>

        {/* 3. Social Links Section */}
        <section className="w-full py-24 flex flex-col items-center">
          <motion.h2 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-3xl md:text-4xl font-heading font-semibold mb-14"
          >
            My Socials
          </motion.h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 w-full max-w-4xl">
            <SocialCard 
              href="https://www.instagram.com/riham_sensi?igsh=cGQzajU0aThmdWxq"
              icon={<Instagram className="w-8 h-8" />}
              title="Instagram"
              username="@riham_sensi"
              delay={0.1}
            />
            <SocialCard 
              href="https://www.instagram.com/mastero.exe?igsh=MXN2OGVmcnRqcmx6Zg=="
              icon={<Instagram className="w-8 h-8" />}
              title="Instagram"
              username="@mastero.exe"
              delay={0.2}
            />
            <SocialCard 
              href="https://www.facebook.com/share/18dPQT7EQx/"
              icon={<Facebook className="w-8 h-8" />}
              title="Facebook"
              username="Riham"
              delay={0.3}
            />
          </div>
        </section>

        {/* 4. Photo Showcase Section */}
        <section className="w-full py-24 flex flex-col items-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-14"
          >
            <h2 className="text-3xl md:text-4xl font-heading font-semibold mb-4">Showcase</h2>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="relative w-full max-w-3xl aspect-[4/5] md:aspect-video rounded-[2.5rem] md:rounded-[3rem] overflow-hidden glass-panel p-2 cursor-pointer group purple-glow-box-hover"
            onClick={() => fileInputRef.current?.click()}
            title="Click to change your photo"
          >
            <motion.div
              animate={{ y: [0, -12, 0] }}
              transition={{ repeat: Infinity, duration: 6, ease: "easeInOut" }}
              className="w-full h-full rounded-[2rem] md:rounded-[2.5rem] overflow-hidden relative flex items-center justify-center bg-white/5"
            >
              {image ? (
                <img 
                  src={image} 
                  alt="Showcase Frame" 
                  className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700" 
                />
              ) : (
                <User className="w-32 h-32 md:w-48 md:h-48 text-slate-500" />
              )}
              
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center backdrop-blur-[2px]">
                <ImagePlus className="w-12 h-12 text-white" />
              </div>
            </motion.div>
          </motion.div>
        </section>

        {/* 5. Footer */}
        <footer className="w-full py-12 mt-10 border-t border-white/5 flex text-center justify-center">
          <p className="text-slate-500 font-medium tracking-wide">© Riham</p>
        </footer>

      </main>
    </div>
  );
}

// Reusable component perfectly adhering to the glassmorphism and purple card requirement
function SocialCard({ href, icon, title, username, delay }: { href: string, icon: React.ReactNode, title: string, username: string, delay: number }) {
  return (
    <motion.a 
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      className="glass-panel flex flex-col items-center justify-center p-10 rounded-[2rem] group purple-glow-box-hover"
    >
      <div className="p-4 bg-white/5 rounded-full mb-6 group-hover:scale-110 group-hover:text-purple-400 group-hover:bg-purple-500/10 transition-all duration-300">
        {icon}
      </div>
      <h3 className="font-heading text-xl font-medium mb-1">{title}</h3>
      <p className="text-slate-400 text-sm group-hover:text-slate-300 transition-colors">{username}</p>
      
      <div className="mt-8 p-3 rounded-full border border-white/10 group-hover:border-purple-500/50 group-hover:bg-purple-500/10 transition-all">
        <ExternalLink className="w-4 h-4 text-slate-400 group-hover:text-purple-400" />
      </div>
    </motion.a>
  );
}
